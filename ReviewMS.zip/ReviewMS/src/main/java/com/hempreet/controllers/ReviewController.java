package com.hempreet.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hempreet.dtos.ReviewDTO;
import com.hempreet.service.ReviewService;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

	@Autowired
	private ReviewService service;

	@PostMapping
	public ResponseEntity<?> saveReview(@Valid @RequestBody ReviewDTO dto,Errors errors) {
		String msg = "";
		if (errors.hasErrors())
		{	msg = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
		return new ResponseEntity<String>(msg,HttpStatus.BAD_REQUEST);
		}
		if (service.saveReview(dto).equalsIgnoreCase("success"))
			return new ResponseEntity<String>("Review successfully saved.", HttpStatus.ACCEPTED);
		return new ResponseEntity<String>("Review not saved!!", HttpStatus.BAD_REQUEST);
	}

	@GetMapping
	public ResponseEntity<?> getAllReviews() {
		List<ReviewDTO> dtos = service.getAllReviews();
		if (dtos == null || dtos.isEmpty())
			return new ResponseEntity<String>("No Reviews", HttpStatus.EXPECTATION_FAILED);
		return new ResponseEntity<List<ReviewDTO>>(dtos,HttpStatus.OK);
	}
}