package com.hempreet.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hempreet.bean.Review;
import com.hempreet.dao.ReviewDao;
import com.hempreet.dtos.ReviewDTO;

@Service
public class ReviewService {

	@Autowired
	private ReviewDao dao;
	
	public String saveReview(ReviewDTO dto) {
		if(dao.saveAndFlush(dto.convertFromDTOToEntity(dto))!=null)
			return "success";
		return "fail";
	}
	
	public List<ReviewDTO> getAllReviews(){
		List<Review> reviews=dao.findAll();
		List<ReviewDTO> dtos=new ArrayList<ReviewDTO>();
		for(Review review:reviews)	dtos.add(review.convertFromEntityToDTO(review));
		return dtos;
	}
}
