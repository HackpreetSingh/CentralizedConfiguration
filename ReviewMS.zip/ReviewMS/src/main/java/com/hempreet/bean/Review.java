package com.hempreet.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hempreet.dtos.ReviewDTO;

@Entity
@Table(name = "Review")
public class Review {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer reviewId;
	
	private String userName;
	
	private Integer movieId;
	
	private Integer rating;
	
	public Review() {
		
	}
	
	
	
	public Review(Integer reviewId, String userName, Integer movieId, Integer rating) {
		super();
		this.reviewId = reviewId;
		this.userName = userName;
		this.movieId = movieId;
		this.rating = rating;
	}



	public Integer getReviewId() {
		return reviewId;
	}



	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public Integer getMovieId() {
		return movieId;
	}



	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}



	public Integer getRating() {
		return rating;
	}



	public void setRating(Integer rating) {
		this.rating = rating;
	}



	public Review(String userName, Integer movieId, Integer rating) {
		this.userName=userName;
		this.movieId=movieId;
		this.rating=rating;
	}
	
	public ReviewDTO convertFromEntityToDTO(Review review) {
		return new ReviewDTO(review.getUserName(), review.getMovieId(), review.getRating());
	}

	
}
