package com.hempreet.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hempreet.bean.Review;

public interface ReviewDao extends JpaRepository<Review, Integer> {

}
