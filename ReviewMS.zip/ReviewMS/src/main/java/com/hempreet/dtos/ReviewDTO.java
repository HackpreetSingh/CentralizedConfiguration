package com.hempreet.dtos;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.hempreet.bean.Review;

public class ReviewDTO {

	@NotEmpty(message = "User Name cannot be empty")
	@NotNull(message = "User Name cannot be null")
	@Size(min = 3,max = 30,message = "User Name size should be 4")
	private String userName;

	@Min(value = 1,message = "Movie Id cannot be less than 1")
	@Max(value = 1000,message = "Movie Id cannot be less than 1000")
	private Integer movieId;

	@Min(value = 0,message = "Rating cannot be less than 0")
	@Max(value = 5,message = "Rating cannot be more than 5")
	private Integer rating;

	public ReviewDTO() {
		
	}
	public ReviewDTO(
			@NotEmpty(message = "User Name cannot be empty") @NotNull(message = "User Name cannot be null") @Size(min = 3, max = 30, message = "User Name size should be 4") String userName,
			@Min(value = 1, message = "Movie Id cannot be less than 1") @Max(value = 1000, message = "Movie Id cannot be less than 1000") Integer movieId,
			@Min(value = 0, message = "Rating cannot be less than 0") @Max(value = 5, message = "Rating cannot be more than 5") Integer rating) {
		super();
		this.userName = userName;
		this.movieId = movieId;
		this.rating = rating;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public Integer getMovieId() {
		return movieId;
	}


	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}


	public Integer getRating() {
		return rating;
	}


	public void setRating(Integer rating) {
		this.rating = rating;
	}


	public Review convertFromDTOToEntity(ReviewDTO dto) {
		return new Review(dto.getUserName(), dto.getMovieId(), dto.getRating());
	}
}
