package com.hempreet.dtos;

public class ReviewDTO {

	private String userName;
	
	private Integer movieId;
	
	private Integer rating;
	
	public ReviewDTO() {}

	public ReviewDTO(String userName, Integer movieId, Integer rating) {
		super();
		this.userName = userName;
		this.movieId = movieId;
		this.rating = rating;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}
	
	
}
