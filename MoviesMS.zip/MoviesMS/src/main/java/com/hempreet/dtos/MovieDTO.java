package com.hempreet.dtos;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.hempreet.bean.Movie;

public class MovieDTO {
	
	private Integer movieId;
	
	@NotEmpty(message = "Name cannot be empty")
	@NotNull(message = "Name cannot be null")
	@Size(min = 3,max = 30,message = "Name size should be between 3 and 30")
	private String movieName;
	
	@NotEmpty(message = "Release Date cannot be empty")
	@NotNull(message = "Release Date cannot be null")
	@Size(min = 4,max = 4,message = "Release Date size should be 4")
	private String releaseDate;
	
	private List<ReviewDTO> reviews;
	
	public MovieDTO() {}
	public MovieDTO(Integer movieId,
			@NotEmpty(message = "Name cannot be empty") @NotNull(message = "Name cannot be null") @Size(min = 3, max = 30, message = "Name size should be between 3 and 30") String movieName,
			@NotEmpty(message = "Release Date cannot be empty") @NotNull(message = "Release Date cannot be null") @Size(min = 4, max = 4, message = "Release Date size should be 4") String releaseDate,
			List<ReviewDTO> reviews) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.releaseDate = releaseDate;
		this.reviews = reviews;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public List<ReviewDTO> getReviews() {
		return reviews;
	}

	public void setReviews(List<ReviewDTO> reviews) {
		this.reviews = reviews;
	}

	public Movie convertFromDTOToEntity(MovieDTO dto) {
		return new Movie(dto.getMovieId(),dto.getMovieName(),dto.getReleaseDate());
	}
}
