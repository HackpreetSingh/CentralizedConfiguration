package com.hempreet.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hempreet.bean.Movie;
import com.hempreet.dao.MovieDao;
import com.hempreet.dtos.MovieDTO;
import com.hempreet.dtos.ReviewDTO;

@Service
public class MovieService {

	@Autowired
	private MovieDao dao;
	
	public String saveMovie(MovieDTO dto) {
		Movie movie=dto.convertFromDTOToEntity(dto);
		if(dao.saveAndFlush(movie)!=null)
			return "success";
		return "Fail";
	}
	
	public List<MovieDTO> getAllMovies(List<ReviewDTO> allReviews){
		List<Movie> movies=dao.findAll();
		List<MovieDTO> dtos=new ArrayList<>();
		for(Movie movie: movies) {
			List<ReviewDTO> reviews=new ArrayList<ReviewDTO>();
			for(ReviewDTO review:allReviews)
				if(review.getMovieId()==movie.getMovieId())
					reviews.add(review);
			dtos.add(movie.convertFromEntityToDTO(movie, reviews));
		}
		return dtos;
	}
}
