package com.hempreet.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hempreet.dtos.MovieDTO;
import com.hempreet.dtos.ReviewDTO;

@Entity
@Table(name = "Movie")
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer movieId;
	
	private String movieName;
	
	private String releaseDate;
	public Movie() {}
	public Movie(Integer movieId, String movieName, String releaseDate) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.releaseDate = releaseDate;
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public MovieDTO convertFromEntityToDTO(Movie movie,List<ReviewDTO> reviews) {
		return new MovieDTO(movie.getMovieId(), movie.getMovieName(), movie.getReleaseDate(), reviews);
	}
}
