package com.hempreet.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hempreet.dtos.MovieDTO;
import com.hempreet.dtos.ReviewDTO;
import com.hempreet.service.MovieService;

@RestController
@RequestMapping("/movies")
public class MoviesController {

	@Autowired
	private MovieService service;

	@Autowired
	private RestTemplate template;

	@PostMapping
	public ResponseEntity<?> saveMovie(@Valid @RequestBody MovieDTO dto, Errors errors) {
		String msg = "";
		if (errors.hasErrors())
		{	msg = errors.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(","));
		return new ResponseEntity<String>(msg,HttpStatus.BAD_REQUEST);
		}
		if (service.saveMovie(dto).equalsIgnoreCase("success"))
			return new ResponseEntity<String>("Movie Successfully saved", HttpStatus.ACCEPTED);
		return new ResponseEntity<String>("Movie not saved!!", HttpStatus.BAD_REQUEST);
	}

	@GetMapping
	public ResponseEntity<?> getAllMovies() {
		ReviewDTO[] reviewsArray= {};
		List<ReviewDTO> reviews=null;
		try{
			reviewsArray = template.getForObject("http://localhost:8081/reviews", ReviewDTO[].class);
			reviews = Arrays.asList(reviewsArray);
		}
		catch (Exception e) {
			reviews=new ArrayList<>();
		}
		System.out.println(reviews);
		List<MovieDTO> dtos = service.getAllMovies(reviews);
		if (dtos == null || dtos.isEmpty())
			return new ResponseEntity<String>("No movies saved!!", HttpStatus.EXPECTATION_FAILED);

		return new ResponseEntity<List<MovieDTO>>(dtos, HttpStatus.OK);
	}

}
