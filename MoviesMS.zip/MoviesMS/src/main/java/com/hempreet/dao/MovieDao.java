package com.hempreet.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hempreet.bean.Movie;

public interface MovieDao extends JpaRepository<Movie, Integer> {

}
